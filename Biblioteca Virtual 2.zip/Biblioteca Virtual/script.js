let books = [];
    let editingBookIndex = null;
    let editingCommentIndex = null;

    function addBook() {
      const title = document.getElementById('bookTitle').value;
      const author = document.getElementById('bookAuthor').value;
      const synopsis = document.getElementById('bookSynopsis').value;
      const file = document.getElementById('bookCoverFile').files[0];

      if (title && author) {
        if (file) {
          const reader = new FileReader();
          reader.onload = function (e) {
            books.push({ title, author, synopsis, cover: e.target.result, comments: [], favorite: false });
            displayBooks();
          };
          reader.readAsDataURL(file);
        } else {
          books.push({ title, author, synopsis, cover: '', comments: [], favorite: false });
          displayBooks();
        }

        document.getElementById('bookTitle').value = '';
        document.getElementById('bookAuthor').value = '';
        document.getElementById('bookSynopsis').value = '';
        document.getElementById('bookCoverFile').value = '';
      }
    }

    function displayBooks(filteredBooks = null) {
      const bookList = document.getElementById('bookList');
      bookList.innerHTML = '';

      const booksToDisplay = filteredBooks || books;
      const sortedBooks = [...booksToDisplay].sort((a, b) => b.favorite - a.favorite);

      sortedBooks.forEach((book, i) => {
        const bookIndex = books.indexOf(book);
        const bookDiv = document.createElement('div');
        bookDiv.className = 'book';
        if (book.favorite) bookDiv.classList.add('favorite');

        const bookContent = document.createElement('div');
        bookContent.className = 'book-content';

        bookContent.innerHTML = `
          <h2>${book.title}</h2>
          <h4>Autor: ${book.author}</h4>
          <div class="synopsis">
            <strong>Sinopse:</strong><br>
            <textarea readonly rows="5" style="width: 95%; resize: none; background: #1e1e1e; border: 1px solid #333; color: white;">${book.synopsis}</textarea>
          </div>
          <input type="text" id="comment-${bookIndex}" placeholder="Comentário..." style="width: 95%;"/>
          <select id="stars-${bookIndex}" style="width: 97%;">
            <option value="1">⭐</option>
            <option value="2">⭐⭐</option>
            <option value="3">⭐⭐⭐</option>
            <option value="4">⭐⭐⭐⭐</option>
            <option value="5">⭐⭐⭐⭐⭐</option>
          </select>
          <button onclick="addComment(${bookIndex})">Comentar</button>
          <button onclick="editBook(${bookIndex})">Editar Livro</button>
          <button class="btnCancelar" onclick="deleteBook(${bookIndex})">Excluir Livro</button>
          <button class="btnFavoritar" onclick="toggleFavorite(${bookIndex})">${book.favorite ? 'Desfavoritar' : 'Favoritar'}</button>
          <div>
            ${book.comments?.map((c, j) => `
              <div class='comment'>
                <span class='stars'>${'⭐'.repeat(c.stars)}</span><br>${c.text}
                <div style="margin-top:5px;">
                  <button onclick="openEditCommentModal(${bookIndex}, ${j})">Editar</button>
                  <button class="btnCancelar" onclick="deleteComment(${bookIndex}, ${j})">Excluir</button>
                </div>
              </div>
            `).join('') || ''}
          </div>
        `;

        const coverImg = document.createElement('img');
        coverImg.className = 'cover';
        if (book.cover) {
          coverImg.src = book.cover;
        }

        bookDiv.appendChild(bookContent);
        bookDiv.appendChild(coverImg);
        bookList.appendChild(bookDiv);
      });
    }

    function filterBooks() {
      const query = document.getElementById('searchInput').value.toLowerCase();
      const filtered = books.filter(book => book.title.toLowerCase().includes(query));
      displayBooks(filtered);
    }

    function editBook(index) {
      editingBookIndex = index;
      const book = books[index];
      document.getElementById('editBookTitle').value = book.title;
      document.getElementById('editBookAuthor').value = book.author;
      document.getElementById('editBookSynopsis').value = book.synopsis;
      document.getElementById('editBookCoverFile').value = '';
      document.getElementById('editBookModal').style.display = 'block';
    }

    function saveEditedBook() {
      const title = document.getElementById('editBookTitle').value;
      const author = document.getElementById('editBookAuthor').value;
      const synopsis = document.getElementById('editBookSynopsis').value;
      const file = document.getElementById('editBookCoverFile').files[0];

      const updateBook = (cover) => {
        books[editingBookIndex] = { ...books[editingBookIndex], title, author, synopsis, cover };
        displayBooks();
        closeBookModal();
      };

      if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
          updateBook(e.target.result);
        };
        reader.readAsDataURL(file);
      } else {
        updateBook(books[editingBookIndex].cover);
      }
    }

    function deleteBook(index) {
      books.splice(index, 1);
      displayBooks();
    }

    function toggleFavorite(index) {
      books[index].favorite = !books[index].favorite;
      displayBooks();
    }

    function addComment(index) {
      const text = document.getElementById(`comment-${index}`).value;
      const stars = parseInt(document.getElementById(`stars-${index}`).value);
      if (text && stars) {
        books[index].comments.push({ text, stars });
        displayBooks();
        document.getElementById(`comment-${index}`).value = '';
      }
    }

    function deleteComment(bookIndex, commentIndex) {
      books[bookIndex].comments.splice(commentIndex, 1);
      displayBooks();
    }

    function openEditCommentModal(bookIndex, commentIndex) {
      editingBookIndex = bookIndex;
      editingCommentIndex = commentIndex;
      const comment = books[bookIndex].comments[commentIndex];
      document.getElementById('editCommentText').value = comment.text;
      document.getElementById('editCommentStars').value = comment.stars;
      document.getElementById('editCommentModal').style.display = 'block';
    }

    function saveEditedComment() {
      const text = document.getElementById('editCommentText').value;
      const stars = parseInt(document.getElementById('editCommentStars').value);
      books[editingBookIndex].comments[editingCommentIndex] = { text, stars };
      displayBooks();
      closeEditCommentModal();
    }

    function closeBookModal() {
      document.getElementById('editBookModal').style.display = 'none';
    }

    function closeEditCommentModal() {
      document.getElementById('editCommentModal').style.display = 'none';
    }